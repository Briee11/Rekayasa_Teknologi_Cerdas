use csv::{Reader, Writer};
use rusty_machine::learning::nnet::{NeuralNet, BCECriterion};
use rusty_machine::learning::optim::grad_desc::StochasticGD;
use rusty_machine::linalg::{Matrix, Vector};
use rusty_machine::prelude::{BaseMatrix, BaseMatrixMut, SupModel};
use rand::prelude::*;
use std::error::Error;
use std::fs::File;
use std::io::{self, Write};
use plotters::prelude::*;

// Structure to hold normalization parameters (means and stds)
struct Normalizer {
    means: Matrix<f64>,
    stds: Matrix<f64>,
}

// Normalize a matrix using provided means and stds, or compute them if not provided
fn normalize(data: &Matrix<f64>, normalizer: Option<&Normalizer>) -> (Matrix<f64>, Option<Normalizer>) {
    let rows = data.rows();
    let cols = data.cols();
    
    let (means, stds) = match normalizer {
        Some(n) => (n.means.clone(), n.stds.clone()),
        None => {
            // Compute mean for each column
            let mut means = Vec::with_capacity(cols);
            for j in 0..cols {
                let column: Vec<f64> = (0..rows).map(|i| data[[i, j]]).collect();
                let mean = column.iter().sum::<f64>() / rows as f64;
                means.push(mean);
            }
            let means = Matrix::new(1, cols, means);
            
            // Compute standard deviation for each column
            let mut variances = Vec::with_capacity(cols);
            for j in 0..cols {
                let column: Vec<f64> = (0..rows).map(|i| data[[i, j]]).collect();
                let mean = means[[0, j]];
                let variance = column.iter().map(|x| (x - mean).powi(2)).sum::<f64>() / rows as f64;
                variances.push(variance.sqrt());
            }
            let stds = Matrix::new(1, cols, variances).apply(&|x| if x == 0.0 { 1.0 } else { x });
            
            (means, stds)
        }
    };
    
    // Normalize: (data - mean) / std
    let mut result_data = vec![0.0; rows * cols];
    for i in 0..rows {
        for j in 0..cols {
            result_data[i * cols + j] = (data[[i, j]] - means[[0, j]]) / stds[[0, j]];
        }
    }
    
    let normalized_matrix = Matrix::new(rows, cols, result_data);
    let new_normalizer = normalizer.is_none().then(|| Normalizer { means, stds });
    
    (normalized_matrix, new_normalizer)
}

fn read_csv_data(file_path: &str) -> Result<(Matrix<f64>, Vector<f64>), Box<dyn Error>> {
    let file = File::open(file_path)?;
    let mut rdr = Reader::from_reader(file);
    
    let mut inputs = Vec::new();
    let mut outputs = Vec::new();
    
    for (i, result) in rdr.records().enumerate() {
        let record = result?;
        if record.len() < 9 {
            return Err(format!("Row {} has fewer than 9 columns", i + 1).into());
        }
        let row: Vec<f64> = record
            .iter()
            .take(8)
            .map(|x| x.parse().map_err(|e| format!("Failed to parse feature in row {}: {}", i + 1, e)))
            .collect::<Result<Vec<f64>, _>>()?;
        let outcome: f64 = record[8]
            .parse()
            .map_err(|e| format!("Failed to parse outcome in row {}: {}", i + 1, e))?;
        
        inputs.push(row);
        outputs.push(outcome);
    }
    
    if inputs.is_empty() {
        return Err("CSV file is empty or contains no valid rows".into());
    }
    
    let input_matrix = Matrix::new(inputs.len(), 8, inputs.into_iter().flatten().collect::<Vec<f64>>());
    let output_vector = Vector::new(outputs);
    
    Ok((input_matrix, output_vector))
}

// Split data into training and test sets
fn split_data(
    inputs: &Matrix<f64>,
    targets: &Vector<f64>,
    train_ratio: f64,
) -> (Matrix<f64>, Vector<f64>, Matrix<f64>, Vector<f64>) {
    let n_samples = inputs.rows();
    let n_train = (n_samples as f64 * train_ratio).round() as usize;
    
    // Create indices and shuffle them
    let mut indices: Vec<usize> = (0..n_samples).collect();
    indices.shuffle(&mut thread_rng());
    
    // Split indices
    let train_indices = &indices[..n_train];
    let test_indices = &indices[n_train..];
    
    // Create training and test sets
    let train_inputs: Vec<f64> = train_indices
        .iter()
        .flat_map(|&i| (0..inputs.cols()).map(move |j| inputs[[i, j]]).collect::<Vec<f64>>())
        .collect();
    let train_targets: Vec<f64> = train_indices.iter().map(|&i| targets[i]).collect();
    
    let test_inputs: Vec<f64> = test_indices
        .iter()
        .flat_map(|&i| (0..inputs.cols()).map(move |j| inputs[[i, j]]).collect::<Vec<f64>>())
        .collect();
    let test_targets: Vec<f64> = test_indices.iter().map(|&i| targets[i]).collect();
    
    (
        Matrix::new(n_train, inputs.cols(), train_inputs),
        Vector::new(train_targets),
        Matrix::new(n_samples - n_train, inputs.cols(), test_inputs),
        Vector::new(test_targets),
    )
}

// Compute binary cross-entropy loss
fn compute_bce_loss(predictions: &Matrix<f64>, targets: &Matrix<f64>) -> f64 {
    let n_samples = predictions.rows();
    let mut loss = 0.0;
    
    for i in 0..n_samples {
        let y = targets[[i, 0]];
        let y_hat = predictions[[i, 0]].clamp(1e-10, 1.0 - 1e-10); // Avoid log(0)
        loss += -(y * y_hat.ln() + (1.0 - y) * (1.0 - y_hat).ln());
    }
    
    loss / n_samples as f64
}

// Compute accuracy
fn compute_accuracy(predictions: &Matrix<f64>, targets: &Matrix<f64>) -> f64 {
    let mut correct = 0;
    let n_samples = predictions.rows();
    
    for i in 0..n_samples {
        let pred = if predictions[[i, 0]] >= 0.5 { 1.0 } else { 0.0 };
        if pred == targets[[i, 0]] {
            correct += 1;
        }
    }
    
    correct as f64 / n_samples as f64
}

// Get user input for 8 parameters
fn get_user_input() -> Result<Vec<f64>, Box<dyn Error>> {
    let feature_names = [
        "Pregnancies",
        "Glucose",
        "BloodPressure",
        "SkinThickness",
        "Insulin",
        "BMI",
        "DiabetesPedigreeFunction",
        "Age",
    ];
    let mut inputs = Vec::with_capacity(8);
    
    println!("Enter the following 8 parameters:");
    for (i, name) in feature_names.iter().enumerate() {
        print!("{}: ", name);
        io::stdout().flush()?;
        
        let mut input = String::new();
        io::stdin().read_line(&mut input)?;
        let value: f64 = input
            .trim()
            .parse()
            .map_err(|e| format!("Invalid input for {}: {}", name, e))?;
        
        inputs.push(value);
    }
    
    Ok(inputs)
}

// Plot training and test metrics
fn plot_metrics(metrics_data: &[(usize, f64, f64, f64, f64)]) -> Result<(), Box<dyn Error>> {
    let root = BitMapBackend::new("training_metrics_plot.png", (800, 600)).into_drawing_area();
    root.fill(&WHITE)?;
    
    let max_epoch = metrics_data.iter().map(|(epoch, _, _, _, _)| *epoch).max().unwrap_or(1) as f32;
    let max_loss = metrics_data
        .iter()
        .map(|(_, train_loss, test_loss, _, _)| f64::max(*train_loss, *test_loss))
        .fold(f64::NEG_INFINITY, f64::max);
    let min_loss = metrics_data
        .iter()
        .map(|(_, train_loss, test_loss, _, _)| f64::min(*train_loss, *test_loss))
        .fold(f64::INFINITY, f64::min);
    let max_acc = metrics_data
        .iter()
        .map(|(_, _, _, train_acc, test_acc)| f64::max(*train_acc, *test_acc))
        .fold(f64::NEG_INFINITY, f64::max);
    let min_acc = metrics_data
        .iter()
        .map(|(_, _, _, train_acc, test_acc)| f64::min(*train_acc, *test_acc))
        .fold(f64::INFINITY, f64::min);
    
    let mut chart = ChartBuilder::on(&root)
        .caption("Training and Test Metrics vs. Epoch", ("sans-serif", 30).into_font())
        .margin(10)
        .x_label_area_size(40)
        .y_label_area_size(50)
        .right_y_label_area_size(50)
        .build_cartesian_2d(0f32..max_epoch, min_loss as f32..max_loss as f32)?
        .set_secondary_coord(0f32..max_epoch, min_acc as f32..max_acc as f32);
    
    chart
        .configure_mesh()
        .x_desc("Epoch")
        .y_desc("Loss")
        .y_label_style(("sans-serif", 15).into_font().color(&BLACK))
        .draw()?;
    
    // Plot training loss
    chart.draw_series(LineSeries::new(
        metrics_data.iter().map(|(epoch, train_loss, _, _, _)| (*epoch as f32, *train_loss as f32)),
        &BLUE,
    ))?
    .label("Train Loss")
    .legend(|(x, y)| PathElement::new(vec![(x, y), (x + 20, y)], &BLUE));
    
    // Plot test loss
    chart.draw_series(LineSeries::new(
        metrics_data.iter().map(|(epoch, _, test_loss, _, _)| (*epoch as f32, *test_loss as f32)),
        &RED,
    ))?
    .label("Test Loss")
    .legend(|(x, y)| PathElement::new(vec![(x, y), (x + 20, y)], &RED));
    
    // Plot training accuracy
    chart.draw_secondary_series(LineSeries::new(
        metrics_data.iter().map(|(epoch, _, _, train_acc, _)| (*epoch as f32, *train_acc as f32)),
        &GREEN,
    ))?
    .label("Train Accuracy")
    .legend(|(x, y)| PathElement::new(vec![(x, y), (x + 20, y)], &GREEN));
    
    // Plot test accuracy
    chart.draw_secondary_series(LineSeries::new(
        metrics_data.iter().map(|(epoch, _, _, _, test_acc)| (*epoch as f32, *test_acc as f32)),
        &MAGENTA,
    ))?
    .label("Test Accuracy")
    .legend(|(x, y)| PathElement::new(vec![(x, y), (x + 20, y)], &MAGENTA));
    
    chart
        .configure_series_labels()
        .background_style(&WHITE.mix(0.8))
        .border_style(&BLACK)
        .position(SeriesLabelPosition::UpperRight)
        .draw()?;
    
    root.present()?;
    Ok(())
}

fn main() -> Result<(), Box<dyn Error>> {
    // Read and preprocess the data
    let (inputs, targets) = read_csv_data("dataset/diabetes.csv")?;
    
    // Validate input matrix dimensions
    if inputs.cols() != 8 {
        return Err(format!("Expected 8 feature columns, found {}", inputs.cols()).into());
    }
    
    // Split data into training and test sets (80% train, 20% test)
    let train_ratio = 0.8;
    let (train_inputs, train_targets, test_inputs, test_targets) = split_data(&inputs, &targets, train_ratio);
    
    // Print dataset sizes
    println!("Training set size: {} samples", train_inputs.rows());
    println!("Test set size: {} samples", test_inputs.rows());
    
    // Normalize the training and test inputs
    let (normalized_train_inputs, normalizer) = normalize(&train_inputs, None);
    let normalizer = normalizer.ok_or("Failed to create normalizer")?;
    let (normalized_test_inputs, _) = normalize(&test_inputs, Some(&normalizer));
    
    // Convert targets to Matrix<f64> for training and accuracy computation
    let train_targets_matrix = Matrix::new(train_targets.size(), 1, train_targets.into_vec());
    let test_targets_matrix = Matrix::new(test_targets.size(), 1, test_targets.into_vec());
    
    // Define neural network architecture
    let layers = vec![8, 16, 1]; // Input: 8, Hidden: 16, Output: 1
    let criterion = BCECriterion::default();
    let mut model = NeuralNet::new(&layers, criterion, StochasticGD::default());
    
    // Training loop with epoch tracking
    let epochs = 100;
    let mut metrics_data = Vec::new();
    
    for epoch in 0..epochs {
        // Train for one epoch
        model.train(&normalized_train_inputs, &train_targets_matrix)?;
        
        // Compute metrics
        let train_predictions = model.predict(&normalized_train_inputs)?;
        let test_predictions = model.predict(&normalized_test_inputs)?;
        
        let train_loss = compute_bce_loss(&train_predictions, &train_targets_matrix);
        let test_loss = compute_bce_loss(&test_predictions, &test_targets_matrix);
        let train_accuracy = compute_accuracy(&train_predictions, &train_targets_matrix);
        let test_accuracy = compute_accuracy(&test_predictions, &test_targets_matrix);
        
        // Store metrics
        metrics_data.push((epoch + 1, train_loss, test_loss, train_accuracy, test_accuracy));
        
        // Print progress every 10 epochs
        if (epoch + 1) % 10 == 0 {
            println!(
                "Epoch: {}, Train Loss: {:.6}, Test Loss: {:.6}, Train Acc: {:.2}%, Test Acc: {:.2}%",
                epoch + 1,
                train_loss,
                test_loss,
                train_accuracy * 100.0,
                test_accuracy * 100.0
            );
        }
    }
    
    // Save metrics data to CSV
    let mut wtr = Writer::from_path("training_metrics.csv")?;
    wtr.write_record(["Epoch", "TrainLoss", "TestLoss", "TrainAccuracy", "TestAccuracy"])?;
    for (epoch, train_loss, test_loss, train_acc, test_acc) in &metrics_data {
        wtr.write_record([
            epoch.to_string(),
            train_loss.to_string(),
            test_loss.to_string(),
            train_acc.to_string(),
            test_acc.to_string(),
        ])?;
    }
    wtr.flush()?;
    
    // Plot metrics
    plot_metrics(&metrics_data)?;
    
    // Compute and print final accuracies
    let train_predictions = model.predict(&normalized_train_inputs)?;
    let test_predictions = model.predict(&normalized_test_inputs)?;
    
    let train_accuracy = compute_accuracy(&train_predictions, &train_targets_matrix);
    let test_accuracy = compute_accuracy(&test_predictions, &test_targets_matrix);
    
    println!("Final Training set accuracy: {:.2}%", train_accuracy * 100.0);
    println!("Final Test set accuracy: {:.2}%", test_accuracy * 100.0);
    
    // Predict for a sample (for reference)
    let sample = Matrix::new(
        1,
        8,
        vec![6.0, 148.0, 72.0, 35.0, 0.0, 33.6, 0.627, 50.0],
    );
    let (sample_normalized, _) = normalize(&sample, Some(&normalizer));
    let sample_prediction = model.predict(&sample_normalized)?;
    
    println!("\nSample Prediction:");
    println!("Prediction probability: {:.2}%", sample_prediction[[0, 0]] * 100.0);
    println!(
        "Result: {}",
        if sample_prediction[[0, 0]] >= 0.5 {
            "Diabetes"
        } else {
            "Not Diabetes"
        }
    );
    
    // Get user input and predict
    println!("\nUser Input Prediction:");
    let user_inputs = get_user_input()?;
    let user_sample = Matrix::new(1, 8, user_inputs);
    let (user_sample_normalized, _) = normalize(&user_sample, Some(&normalizer));
    let user_prediction = model.predict(&user_sample_normalized)?;
    
    println!("\nUser Input Prediction Result:");
    println!("Prediction probability: {:.2}%", user_prediction[[0, 0]] * 100.0);
    println!(
        "Result: {}",
        if user_prediction[[0, 0]] >= 0.5 {
            "Diabetes"
        } else {
            "Not Diabetes"
        }
    );
    
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;
    
    #[test]
    fn test_read_csv() {
        let result = read_csv_data("dataset/diabetes.csv");
        assert!(result.is_ok(), "Failed to read dataset/diabetes.csv: {:?}", result.err());
        let (inputs, targets) = result.unwrap();
        assert_eq!(inputs.cols(), 8, "Input matrix should have 8 columns");
        assert_eq!(inputs.rows(), targets.size(), "Number of rows should match number of targets");
    }
}