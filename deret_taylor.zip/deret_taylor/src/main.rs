use std::f64::consts::PI;
use std::io;

// Fungsi faktorial untuk membantu perhitungan deret Taylor
fn factorial(n: u32) -> u64 {
    if n == 0 {
        1
    } else {
        (1..=n as u64).product()
    }
}

// Fungsi deret Taylor untuk sin(x)
fn taylor_sin(x: f64, terms: u32) -> f64 {
    let mut result = 0.0;
    let x = x % (2.0 * PI); // Normalisasi sudut ke rentang [0, 2π]

    for n in 0..terms {
        let sign = if n % 2 == 0 { 1.0 } else { -1.0 };
        let term = sign * x.powi((2 * n + 1) as i32) / factorial(2 * n + 1) as f64;
        result += term;
    }
    result
}

// Fungsi deret Taylor untuk cos(x)
fn taylor_cos(x: f64, terms: u32) -> f64 {
    let mut result = 0.0;
    let x = x % (2.0 * PI); // Normalisasi sudut ke rentang [0, 2π]

    for n in 0..terms {
        let sign = if n % 2 == 0 { 1.0 } else { -1.0 };
        let term = sign * x.powi((2 * n) as i32) / factorial(2 * n) as f64;
        result += term;
    }
    result
}

fn main() {
    // Tampilkan rumus deret Taylor
    println!("Rumus Deret Taylor:");
    println!("sin(x) = Σ[n=0 to ∞] ((-1)^n * x^(2n+1)) / (2n+1)!");
    println!("cos(x) = Σ[n=0 to ∞] ((-1)^n * x^(2n)) / (2n)!");
    println!();

    // Input sudut dalam radian
    println!("Masukkan sudut dalam radian (contoh: 0.785 untuk π/4):");
    let mut angle_input = String::new();
    io::stdin()
        .read_line(&mut angle_input)
        .expect("Gagal membaca input");
    let angle: f64 = angle_input
        .trim()
        .parse()
        .expect("Masukkan angka yang valid untuk sudut");

    // Input jumlah suku
    println!("Masukkan jumlah suku deret Taylor (contoh: 10):");
    let mut terms_input = String::new();
    io::stdin()
        .read_line(&mut terms_input)
        .expect("Gagal membaca input");
    let terms: u32 = terms_input
        .trim()
        .parse()
        .expect("Masukkan angka bulat positif untuk jumlah suku");

    // Hitung sin dan cos menggunakan deret Taylor
    let sin_result = taylor_sin(angle, terms);
    let cos_result = taylor_cos(angle, terms);

    // Cetak hasil
    println!("\nsin({:.2} rad) ≈ {:.6}", angle, sin_result);
    println!("cos({:.2} rad) ≈ {:.6}", angle, cos_result);

    // Untuk perbandingan, cetak nilai sin dan cos bawaan Rust
    println!("sin bawaan: {:.6}", angle.sin());
    println!("cos bawaan: {:.6}", angle.cos());
}