use std::f64::consts::PI;
use std::io;

// Struktur untuk menyimpan lookup table
struct TrigTable {
    angles: Vec<f64>,
    sin_values: Vec<f64>,
    cos_values: Vec<f64>,
    step: f64,
}

// Fungsi untuk membuat lookup table
fn create_trig_table(num_points: usize) -> TrigTable {
    let mut angles = Vec::new();
    let mut sin_values = Vec::new();
    let mut cos_values = Vec::new();
    let step = 2.0 * PI / num_points as f64;

    for i in 0..=num_points {
        let angle = i as f64 * step;
        angles.push(angle);
        sin_values.push(angle.sin());
        cos_values.push(angle.cos());
    }

    TrigTable {
        angles,
        sin_values,
        cos_values,
        step,
    }
}

// Fungsi interpolasi linier
fn linear_interpolate(x0: f64, y0: f64, x1: f64, y1: f64, x: f64) -> f64 {
    y0 + (y1 - y0) * (x - x0) / (x1 - x0)
}

// Fungsi untuk mencari nilai sin dari lookup table
fn lookup_sin(table: &TrigTable, x: f64) -> f64 {
    let x = x % (2.0 * PI); // Normalisasi sudut ke [0, 2π]
    let x = if x < 0.0 { x + 2.0 * PI } else { x }; // Tangani sudut negatif

    let index = (x / table.step).floor() as usize;
    if index >= table.angles.len() - 1 {
        return table.sin_values[table.angles.len() - 1];
    }

    let x0 = table.angles[index];
    let x1 = table.angles[index + 1];
    let y0 = table.sin_values[index];
    let y1 = table.sin_values[index + 1];

    linear_interpolate(x0, y0, x1, y1, x)
}

// Fungsi untuk mencari nilai cos dari lookup table
fn lookup_cos(table: &TrigTable, x: f64) -> f64 {
    let x = x % (2.0 * PI); // Normalisasi sudut ke [0, 2π]
    let x = if x < 0.0 { x + 2.0 * PI } else { x }; // Tangani sudut negatif

    let index = (x / table.step).floor() as usize;
    if index >= table.angles.len() - 1 {
        return table.cos_values[table.angles.len() - 1];
    }

    let x0 = table.angles[index];
    let x1 = table.angles[index + 1];
    let y0 = table.cos_values[index];
    let y1 = table.cos_values[index + 1];

    linear_interpolate(x0, y0, x1, y1, x)
}

fn main() {
    // Tampilkan rumus interpolasi linier
    println!("Rumus Interpolasi Linier:");
    println!("y = y0 + (y1 - y0) * (x - x0) / (x1 - x0)");
    println!("(Digunakan untuk menghitung sin(x) dan cos(x) di antara titik-titik tabel)");
    println!();

    // Input sudut dalam radian
    println!("Masukkan sudut dalam radian (contoh: 0.785 untuk π/4):");
    let mut angle_input = String::new();
    io::stdin()
        .read_line(&mut angle_input)
        .expect("Gagal membaca input");
    let angle: f64 = angle_input
        .trim()
        .parse()
        .expect("Masukkan angka yang valid untuk sudut");

    // Input jumlah titik dalam lookup table
    println!("Masukkan jumlah titik dalam lookup table (contoh: 100):");
    let mut points_input = String::new();
    io::stdin()
        .read_line(&mut points_input)
        .expect("Gagal membaca input");
    let num_points: usize = points_input
        .trim()
        .parse()
        .expect("Masukkan angka bulat positif untuk jumlah titik");

    // Buat lookup table
    let table = create_trig_table(num_points);

    // Hitung sin dan cos menggunakan lookup table
    let sin_result = lookup_sin(&table, angle);
    let cos_result = lookup_cos(&table, angle);

    // Cetak hasil
    println!("\nsin({:.2} rad) ≈ {:.6}", angle, sin_result);
    println!("cos({:.2} rad) ≈ {:.6}", angle, cos_result);

    // Untuk perbandingan, cetak nilai sin dan cos bawaan Rust
    println!("sin bawaan: {:.6}", angle.sin());
    println!("cos bawaan: {:.6}", angle.cos());
}